
using System;
using System.ComponentModel.DataAnnotations;

namespace KutuphaneYonetimSistemi.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; }

        [Required]
        public string Author { get; set; }

        public string Publisher { get; set; }

        [Range(1000, 3000)]
        public int? Year { get; set; }
    }
}
