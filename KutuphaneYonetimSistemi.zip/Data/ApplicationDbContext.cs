
using Microsoft.EntityFrameworkCore;
using KutuphaneYonetimSistemi.Models;

namespace KutuphaneYonetimSistemi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
    }
}
