
using System.ComponentModel.DataAnnotations;

namespace KutuphaneYonetimSistemi.ViewModels
{
    public class BookViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Kitap adı zorunludur.")]
        [Display(Name = "Kitap Adı")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Yazar adı zorunludur.")]
        [Display(Name = "Yazar")]
        public string Author { get; set; }

        [Display(Name = "Yayınevi")]
        public string Publisher { get; set; }

        [Display(Name = "Yayın Yılı")]
        [Range(1000, 3000, ErrorMessage = "Geçerli bir yıl girin.")]
        public int? Year { get; set; }
    }
}
